import streamlit as st
import pandas as pd
import numpy as np
import pickle
from pathlib import Path

# ─────────────────────────────────────────────
# Konfigurasi halaman
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Prediksi Harga Rumah",
    page_icon="🏠",
    layout="centered",
)

# ─────────────────────────────────────────────
# Path model (relatif agar kompatibel Streamlit Cloud)
# ─────────────────────────────────────────────
MODEL_PATH = Path(__file__).parent / "adaboost_rumah.pkcls"

# ─────────────────────────────────────────────
# Konfigurasi fitur
# Nama kolom HARUS sama persis dengan nama variabel saat training di Orange.
# ─────────────────────────────────────────────
FEATURE_CONFIG = {
    "X1 transaction date": {
        "label": "Tanggal Transaksi (tahun desimal)",
        "type": "numeric",
        "input": "number",
        "min": 2010.0,
        "max": 2030.0,
        "default": 2013.5,
        "step": 0.083,          # ≈ 1 bulan
        "format": "%.3f",
        "help": "Contoh: 2013.583 ≈ Juli 2013",
    },
    "X2 house age": {
        "label": "Usia Rumah (tahun)",
        "type": "numeric",
        "input": "slider",
        "min": 0.0,
        "max": 50.0,
        "default": 16.0,
        "step": 0.5,
        "help": "Usia bangunan dalam tahun",
    },
    "X3 distance to the nearest MRT station": {
        "label": "Jarak ke Stasiun MRT Terdekat (meter)",
        "type": "numeric",
        "input": "number",
        "min": 0.0,
        "max": 10000.0,
        "default": 1083.0,
        "step": 10.0,
        "format": "%.1f",
        "help": "Semakin dekat ke stasiun MRT, umumnya harga lebih tinggi",
    },
    "X4 number of convenience stores": {
        "label": "Jumlah Minimarket Terdekat",
        "type": "numeric",
        "input": "slider",
        "min": 0,
        "max": 15,
        "default": 4,
        "step": 1,
        "help": "Jumlah minimarket/convenience store dalam radius dekat",
    },
    "X5 latitude": {
        "label": "Latitude",
        "type": "numeric",
        "input": "number",
        "min": 24.9,
        "max": 25.1,
        "default": 24.97,
        "step": 0.001,
        "format": "%.5f",
        "help": "Koordinat lintang lokasi properti",
    },
    "X6 longitude": {
        "label": "Longitude",
        "type": "numeric",
        "input": "number",
        "min": 121.4,
        "max": 121.7,
        "default": 121.53,
        "step": 0.001,
        "format": "%.5f",
        "help": "Koordinat bujur lokasi properti",
    },
}


# ─────────────────────────────────────────────
# Load model (di-cache agar tidak reload tiap interaksi)
# ─────────────────────────────────────────────
@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            f"File model tidak ditemukan: {MODEL_PATH}\n"
            "Pastikan file 'adaboost_rumah.pkcls' ada di repository GitHub yang sama."
        )
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    return model


# ─────────────────────────────────────────────
# Prediksi menggunakan scikit-learn interface
# ─────────────────────────────────────────────
def predict_sklearn(model, input_df: pd.DataFrame):
    """Coba prediksi langsung dengan interface scikit-learn (.predict)."""
    skl_model = getattr(model, "skl_model", None)
    if skl_model is not None:
        values = input_df.values.astype(float)
        pred = skl_model.predict(values)
        return float(pred[0]), None
    raise AttributeError("Atribut 'skl_model' tidak ditemukan.")


# ─────────────────────────────────────────────
# Prediksi menggunakan Orange interface (fallback)
# ─────────────────────────────────────────────
def predict_orange(model, input_df: pd.DataFrame):
    """Fallback: konversi input ke Orange.data.Table lalu prediksi."""
    import Orange.data as od

    domain = getattr(model, "domain", None)
    if domain is None:
        raise AttributeError("Model tidak memiliki atribut 'domain'.")

    # Ambil hanya fitur (bukan class/target)
    attrs = domain.attributes
    col_names = [a.name for a in attrs]

    # Susun ulang input sesuai urutan domain Orange
    row = [float(input_df[c].iloc[0]) for c in col_names]
    X = np.array([row])

    table = od.Table.from_numpy(
        od.Domain(attrs),
        X,
    )
    pred = model(table)
    return float(pred[0]), None


# ─────────────────────────────────────────────
# Fungsi prediksi utama (sklearn dulu, lalu Orange)
# ─────────────────────────────────────────────
def predict_with_model(model, input_df: pd.DataFrame):
    errors = []

    # Percobaan 1: sklearn
    try:
        result, conf = predict_sklearn(model, input_df)
        return result, conf, "scikit-learn"
    except Exception as e:
        errors.append(f"sklearn: {e}")

    # Percobaan 2: Orange
    try:
        result, conf = predict_orange(model, input_df)
        return result, conf, "Orange"
    except Exception as e:
        errors.append(f"Orange: {e}")

    raise RuntimeError("Semua metode prediksi gagal:\n" + "\n".join(errors))


# ─────────────────────────────────────────────
# Form input
# ─────────────────────────────────────────────
def create_input_form():
    input_data = {}
    with st.form("prediction_form"):
        st.subheader("📋 Masukkan Data Properti")
        for col_name, cfg in FEATURE_CONFIG.items():
            label = cfg["label"]
            help_text = cfg.get("help", "")
            if cfg["type"] == "numeric":
                if cfg["input"] == "slider":
                    val = st.slider(
                        label,
                        min_value=float(cfg["min"]),
                        max_value=float(cfg["max"]),
                        value=float(cfg["default"]),
                        step=float(cfg.get("step", 1.0)),
                        help=help_text,
                    )
                else:  # number_input
                    val = st.number_input(
                        label,
                        min_value=float(cfg["min"]),
                        max_value=float(cfg["max"]),
                        value=float(cfg["default"]),
                        step=float(cfg.get("step", 1.0)),
                        format=cfg.get("format", "%.2f"),
                        help=help_text,
                    )
                input_data[col_name] = val
            elif cfg["type"] == "categorical":
                val = st.selectbox(label, options=cfg["options"], help=help_text)
                input_data[col_name] = val

        submitted = st.form_submit_button("🔍 Prediksi Harga", use_container_width=True)
    return submitted, input_data


# ─────────────────────────────────────────────
# Tampilan utama
# ─────────────────────────────────────────────
def main():
    # ── Sidebar ──
    with st.sidebar:
        st.title("ℹ️ Panduan")
        st.markdown(
            """
**Cara penggunaan:**
1. Isi semua kolom data properti di form utama.
2. Klik tombol **Prediksi Harga**.
3. Hasil prediksi harga per unit area akan ditampilkan.

---
**Tentang model:**
- Algoritma: **AdaBoost Regressor** (via Orange Data Mining)
- File model: `adaboost_rumah.pkcls`
- Model dimuat dari file `.pkcls` di GitHub repository yang sama.

---
**Catatan fitur:**
- *Tanggal transaksi* dalam format tahun desimal (mis. 2013.583 = Juli 2013).
- *Jarak MRT* dalam satuan meter.
- *Koordinat* menggunakan sistem WGS84.
"""
        )

    # ── Header ──
    st.title("🏠 Aplikasi Prediksi Harga Rumah")
    st.markdown(
        "Aplikasi ini menggunakan model machine learning **AdaBoost Regressor** "
        "hasil training dari **Orange Data Mining** dan dijalankan melalui **Streamlit Cloud**."
    )
    st.divider()

    # ── Load model ──
    try:
        model = load_model()
    except FileNotFoundError as e:
        st.error(f"❌ {e}")
        st.stop()
    except Exception as e:
        st.error(f"❌ Gagal memuat model: {e}")
        st.stop()

    # ── Form & prediksi ──
    submitted, input_data = create_input_form()

    if submitted:
        input_df = pd.DataFrame([input_data], columns=list(FEATURE_CONFIG.keys()))

        st.divider()
        st.subheader("📊 Data yang Dimasukkan")
        display_df = input_df.copy()
        display_df.columns = [FEATURE_CONFIG[c]["label"] for c in display_df.columns]
        st.dataframe(display_df.T.rename(columns={0: "Nilai"}), use_container_width=True)

        with st.spinner("Menjalankan prediksi…"):
            try:
                result, confidence, method = predict_with_model(model, input_df)

                st.divider()
                st.subheader("🎯 Hasil Prediksi")
                st.success(
                    f"**Harga per Unit Area yang Diprediksi: {result:,.2f}**\n\n"
                    f"*(Satuan: 10.000 TWD / ping — setara luas ±3,3 m²)*"
                )
                st.caption(f"Metode prediksi: `{method}`")

                if confidence is not None:
                    st.info(f"Confidence / probabilitas: {confidence}")

                st.markdown(
                    "> **Interpretasi:** Nilai prediksi adalah harga properti per unit area "
                    "dalam satuan 10.000 New Dollar Taiwan (TWD) per ping (~3,3 m²). "
                    "Kalikan hasilnya dengan luas properti (dalam ping) untuk mendapat estimasi harga total."
                )

            except RuntimeError as e:
                st.error(f"❌ Prediksi gagal.\n\n{e}")
            except ModuleNotFoundError:
                st.error(
                    "❌ Library `orange3` tidak tersedia di lingkungan ini. "
                    "Pastikan `orange3` tercantum di `requirements.txt` dan sudah terinstall."
                )
            except Exception as e:
                st.error(f"❌ Terjadi kesalahan tak terduga: {e}")


if __name__ == "__main__":
    main()
